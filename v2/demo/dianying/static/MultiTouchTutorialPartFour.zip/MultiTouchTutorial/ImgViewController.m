//
//  ImgViewController.m
//  MultiTouchTutorial
//
//  Created by iPhone SDK Articles on 9/21/08.
//  Copyright 2008 www.iPhoneSDKArticles.com. All rights reserved.
//

#import "ImgViewController.h"


@implementation ImgViewController

/*
// Override initWithNibName:bundle: to load the view using a nib file then perform additional customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically.
- (void)loadView {
}
*/

/*
// Implement viewDidLoad to do additional setup after loading the view.
- (void)viewDidLoad {
    [super viewDidLoad];
}
*/


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
    // Release anything that's not essential, such as cached data
}


- (void)dealloc {
	[timer release];
	[imgView release];
    [super dealloc];
}

-(void) showAlertView:(NSTimer *)theTimer {

	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Birth of a star" message:@"Timer ended. Event Fired."
												   delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
	[alert show];
	[alert release];
	
}

#pragma mark -
#pragma mark <Touches Began/Moved/Ended/Cancelled Methods>

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
	
	NSSet *allTouches = [event allTouches];
	
	switch ([allTouches count]) {
		case 1: { //Single touch
			
			//Get the first touch.
			UITouch *touch = [[allTouches allObjects] objectAtIndex:0];
			
			switch ([touch tapCount])
			{
				case 1: //Single Tap.
				{
					//Start a timer for 2 seconds.
					timer = [NSTimer scheduledTimerWithTimeInterval:2 target:self 
														   selector:@selector(showAlertView:) userInfo:nil repeats:NO];
					
					[timer retain];
				} break;
				case 2: {//Double tap. 
					
					//Track the initial distance between two fingers.
					UITouch *touch1 = [[allTouches allObjects] objectAtIndex:0];
					UITouch *touch2 = [[allTouches allObjects] objectAtIndex:1];
					
					initialDistance = [self distanceBetweenTwoPoints:[touch1 locationInView:[self view]] 
															 toPoint:[touch2 locationInView:[self view]]];
				} break;
			}
		} break;
		case 2: { //Double Touch
			
		} break;
		default:
		break;
	}
	
}

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event {
	
	if([timer isValid])
		[timer invalidate];
	
	NSSet *allTouches = [event allTouches];
	
	switch ([allTouches count])
	{
		case 1: {
			//The image is being panned (moved left or right)
			UITouch *touch = [[allTouches allObjects] objectAtIndex:0];
			CGPoint centerPoint = [touch locationInView:[self view]];
			
			[imgView setCenter:centerPoint];
			
		} break;
		case 2: {
			//The image is being zoomed in or out.
			
			UITouch *touch1 = [[allTouches allObjects] objectAtIndex:0];
			UITouch *touch2 = [[allTouches allObjects] objectAtIndex:1];
			
			//Calculate the distance between the two fingers.
			CGFloat finalDistance = [self distanceBetweenTwoPoints:[touch1 locationInView:[self view]]
														   toPoint:[touch2 locationInView:[self view]]];
			
			//Check if zoom in or zoom out.
			if(initialDistance > finalDistance) {
				NSLog(@"Zoom Out");
			} 
			else {
				NSLog(@"Zoom In");
			}
			
		} break;
	}
	
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event { 
	
	if([timer isValid])
		[timer invalidate];
	
	//Get all the touches.
	NSSet *allTouches = [event allTouches];
	
	//Number of touches on the screen
	switch ([allTouches count])
	{
		case 1:
		{
			//Get the first touch.
			UITouch *touch = [[allTouches allObjects] objectAtIndex:0];
			
			switch([touch tapCount])
			{
				case 1://Single tap
					imgView.contentMode = UIViewContentModeScaleAspectFit;
					break;
				case 2://Double tap.
					imgView.contentMode = UIViewContentModeCenter;
					break;
			}
		}	
		break;
	}
	
	[self clearTouches];
	
}

- (void) touchesCanceled {

	[self clearTouches];
	
}

- (CGFloat)distanceBetweenTwoPoints:(CGPoint)fromPoint toPoint:(CGPoint)toPoint {

	float x = toPoint.x - fromPoint.x;
    float y = toPoint.y - fromPoint.y;
    
    return sqrt(x * x + y * y);
}

- (void)clearTouches {

	initialDistance = -1;
}

@end
