//
//  ImgViewController.h
//  MultiTouchTutorial
//
//  Created by iPhone SDK Articles on 9/21/08.
//  Copyright 2008 www.iPhoneSDKArticles.com. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ImgViewController : UIViewController {
	
	IBOutlet UIImageView *imgView;
	NSTimer *timer;
	CGFloat initialDistance;

}

- (CGFloat)distanceBetweenTwoPoints:(CGPoint)fromPoint toPoint:(CGPoint)toPoint;
- (void) clearTouches;

@end
